// =====================================================================
//  SuperCopy.cs  -  lightweight "Super Copier" for Windows XP .. 11
//  C# 2.0 / .NET Framework 2.0, compiled with csc.exe (no Visual Studio)
//
//  Modes (command line):
//    SuperCopy.exe                    open Settings (install / remove menu)
//    SuperCopy.exe /install           add Explorer right-click entries
//    SuperCopy.exe /uninstall         remove them
//    SuperCopy.exe /copy <paths...>   remember items (silent)
//    SuperCopy.exe /cut  <paths...>   remember items for a move (silent)
//    SuperCopy.exe /paste <folder>    copy/move remembered items here
// =====================================================================

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: System.Reflection.AssemblyTitle("Super Copy")]
[assembly: System.Reflection.AssemblyDescription("Lightweight multi-threaded file copier")]
[assembly: System.Reflection.AssemblyVersion("1.0.0.0")]

namespace SuperCopyApp
{
    // ================================================================
    //  Program entry (kept tiny so /copy and /cut start very fast:
    //  the WinForms code is only JIT-compiled when a window is needed)
    // ================================================================
    static class Program
    {
        [STAThread]
        static int Main(string[] args)
        {
            string mode = args.Length > 0 ? args[0].ToLower() : "/settings";
            List<string> rest = new List<string>();
            for (int i = 1; i < args.Length; i++)
            {
                string a = args[i].Trim('"');
                if (a.Length > 0) rest.Add(a);
            }

            Paths.Init();

            if (mode == "/copy" || mode == "/cut")
            {
                try { if (rest.Count > 0) ClipStore.Add(mode == "/cut", rest.ToArray()); }
                catch { }
                return 0;
            }
            return Gui(mode, rest);
        }

        static int Gui(string mode, List<string> rest)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Settings.Load();
            try
            {
                switch (mode)
                {
                    case "/paste":
                        return DoPaste(string.Join(" ", rest.ToArray()));
                    case "/install":
                        ShellIntegration.Install();
                        MessageBox.Show("Explorer menu installed.", "Super Copy", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return 0;
                    case "/uninstall":
                        ShellIntegration.Uninstall();
                        MessageBox.Show("Explorer menu removed.", "Super Copy", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return 0;
                    default:
                        Application.Run(new SettingsForm());
                        return 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Super Copy", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
        }

        static int DoPaste(string dest)
        {
            dest = dest.Trim().Trim('"');
            // "D:\" arrives as  D:"  because of the quote-escaping rule
            if (dest.Length == 2 && dest[1] == ':') dest += "\\";
            if (dest.Length == 0 || !Directory.Exists(dest))
            {
                MessageBox.Show("Destination folder not found:\n" + dest, "Super Copy", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return 1;
            }

            bool cut;
            List<string> src = ClipStore.Read(out cut);
            if (src.Count == 0)
            {
                MessageBox.Show("Nothing to paste.\nRight-click a file or folder and choose \"Super Copy\" first.",
                    "Super Copy", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return 0;
            }

            bool created;
            Mutex m = new Mutex(true, "SuperCopy_MainInstance_v1", out created);
            if (!created)
            {
                // another window is already running: hand the job over through the queue folder
                QueueStore.Enqueue(cut, dest, src);
                if (cut) ClipStore.Clear();
                m.Close();
                return 0;
            }
            try
            {
                if (cut) ClipStore.Clear();
                Application.Run(new MainForm(new CopyJob(src, dest, cut)));
            }
            finally
            {
                try { m.ReleaseMutex(); } catch { }
                m.Close();
            }
            return 0;
        }
    }

    // ================================================================
    //  Paths + Settings
    // ================================================================
    static class Paths
    {
        public static string AppDir, ClipFile, QueueDir, Ini, IcoFile, ExeInstalled;

        public static void Init()
        {
            string ad = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            if (ad == null || ad.Length == 0) ad = Path.GetTempPath();
            AppDir = Path.Combine(ad, "SuperCopy");
            ClipFile = Path.Combine(AppDir, "clipboard.txt");
            QueueDir = Path.Combine(AppDir, "queue");
            Ini = Path.Combine(AppDir, "settings.ini");
            IcoFile = Path.Combine(AppDir, "SuperCopy.ico");
            ExeInstalled = Path.Combine(AppDir, "SuperCopy.exe");
            try { Directory.CreateDirectory(QueueDir); } catch { }
        }
    }

    static class Settings
    {
        public static volatile int Concurrency = 2;   // simultaneous file copies (1..8)
        public static volatile int BufferKB = 256;    // copy buffer per thread
        public static volatile int Conflict = 0;      // 0 overwrite, 1 skip, 2 keep both, 3 overwrite if newer
        public static bool AutoClose = false;

        static int Clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

        public static void Load()
        {
            try
            {
                if (!File.Exists(Paths.Ini)) return;
                foreach (string line in File.ReadAllLines(Paths.Ini))
                {
                    int i = line.IndexOf('=');
                    if (i <= 0) continue;
                    string k = line.Substring(0, i).Trim().ToLower();
                    string v = line.Substring(i + 1).Trim();
                    int n;
                    switch (k)
                    {
                        case "concurrency": if (int.TryParse(v, out n)) Concurrency = Clamp(n, 1, 8); break;
                        case "bufferkb": if (int.TryParse(v, out n)) BufferKB = Clamp(n, 16, 16384); break;
                        case "conflict": if (int.TryParse(v, out n)) Conflict = Clamp(n, 0, 3); break;
                        case "autoclose": AutoClose = (v == "1"); break;
                    }
                }
            }
            catch { }
        }

        public static void Save()
        {
            try
            {
                File.WriteAllLines(Paths.Ini, new string[] {
                    "Concurrency=" + Concurrency,
                    "BufferKB=" + BufferKB,
                    "Conflict=" + Conflict,
                    "AutoClose=" + (AutoClose ? "1" : "0") });
            }
            catch { }
        }
    }

    // ================================================================
    //  "Clipboard" (list of items remembered by Super Copy / Super Cut)
    // ================================================================
    static class ClipStore
    {
        public static void Add(bool cut, string[] paths)
        {
            Mutex m = new Mutex(false, "SuperCopy_ClipLock_v1");
            bool owned = false;
            try
            {
                try { owned = m.WaitOne(3000, false); } catch { }
                string mode = cut ? "cut" : "copy";
                List<string> list = new List<string>();
                string f = Paths.ClipFile;
                // clicks that arrive within 3 s of each other belong to one multi-selection
                if (File.Exists(f) && (DateTime.Now - File.GetLastWriteTime(f)).TotalMilliseconds < 3000)
                {
                    string[] old = File.ReadAllLines(f, Encoding.UTF8);
                    if (old.Length > 0 && old[0] == mode)
                        for (int i = 1; i < old.Length; i++) if (old[i].Length > 0) list.Add(old[i]);
                }
                for (int i = 0; i < paths.Length; i++)
                    if (!list.Contains(paths[i])) list.Add(paths[i]);

                string[] lines = new string[list.Count + 1];
                lines[0] = mode;
                list.CopyTo(lines, 1);
                File.WriteAllLines(f, lines, Encoding.UTF8);
            }
            finally
            {
                if (owned) { try { m.ReleaseMutex(); } catch { } }
                m.Close();
            }
        }

        public static List<string> Read(out bool cut)
        {
            cut = false;
            List<string> r = new List<string>();
            try
            {
                if (!File.Exists(Paths.ClipFile)) return r;
                string[] ln = File.ReadAllLines(Paths.ClipFile, Encoding.UTF8);
                if (ln.Length > 0)
                {
                    cut = (ln[0] == "cut");
                    for (int i = 1; i < ln.Length; i++) if (ln[i].Length > 0) r.Add(ln[i]);
                }
            }
            catch { }
            return r;
        }

        public static void Clear()
        {
            try { File.Delete(Paths.ClipFile); } catch { }
        }
    }

    static class QueueStore
    {
        public static void Enqueue(bool cut, string dest, List<string> src)
        {
            List<string> lines = new List<string>();
            lines.Add(cut ? "cut" : "copy");
            lines.Add(dest);
            lines.AddRange(src);
            string name = DateTime.Now.Ticks.ToString("D19") + "_" + Guid.NewGuid().ToString("N").Substring(0, 6);
            string tmp = Path.Combine(Paths.QueueDir, name + ".tmp");
            string fin = Path.Combine(Paths.QueueDir, name + ".job");
            File.WriteAllLines(tmp, lines.ToArray(), Encoding.UTF8);
            File.Move(tmp, fin);
        }
    }

    // ================================================================
    //  Explorer context menu (HKCU\Software\Classes - no admin needed)
    // ================================================================
    static class ShellIntegration
    {
        [DllImport("shell32.dll")]
        static extern void SHChangeNotify(int wEventId, uint uFlags, IntPtr dwItem1, IntPtr dwItem2);

        static readonly string[] AllKeys = new string[] {
            @"*\shell\SuperCopy.Copy",
            @"*\shell\SuperCopy.Cut",
            @"Directory\shell\SuperCopy.Copy",
            @"Directory\shell\SuperCopy.Cut",
            @"Directory\shell\SuperCopy.Paste",
            @"Directory\Background\shell\SuperCopy.Paste",
            @"Drive\shell\SuperCopy.Paste" };

        static void Verb(RegistryKey root, string path, string label, string ico, string cmd)
        {
            using (RegistryKey k = root.CreateSubKey(path))
            {
                k.SetValue("", label);
                k.SetValue("Icon", ico);
            }
            using (RegistryKey c = root.CreateSubKey(path + @"\command"))
            {
                c.SetValue("", cmd);
            }
        }

        public static bool IsInstalled()
        {
            try
            {
                using (RegistryKey k = Registry.CurrentUser.OpenSubKey(@"Software\Classes\Directory\shell\SuperCopy.Paste"))
                    return k != null;
            }
            catch { return false; }
        }

        public static void Install()
        {
            string self = Application.ExecutablePath;
            string exe = Paths.ExeInstalled;
            // keep a stable copy so the menu keeps working if the build folder is deleted
            if (!string.Equals(Path.GetFullPath(self), Path.GetFullPath(exe), StringComparison.OrdinalIgnoreCase))
            {
                try { File.Copy(self, exe, true); }
                catch { if (!File.Exists(exe)) exe = self; }
            }
            string ico = Paths.IcoFile;
            try { IconMaker.WriteIco(ico); } catch { ico = exe + ",0"; }

            using (RegistryKey cls = Registry.CurrentUser.CreateSubKey(@"Software\Classes"))
            {
                string q = "\"" + exe + "\"";
                Verb(cls, AllKeys[0], "Super Copy", ico, q + " /copy \"%1\"");
                Verb(cls, AllKeys[1], "Super Cut (move)", ico, q + " /cut \"%1\"");
                Verb(cls, AllKeys[2], "Super Copy", ico, q + " /copy \"%1\"");
                Verb(cls, AllKeys[3], "Super Cut (move)", ico, q + " /cut \"%1\"");
                Verb(cls, AllKeys[4], "Super Paste here", ico, q + " /paste \"%1\"");
                Verb(cls, AllKeys[5], "Super Paste here", ico, q + " /paste \"%V\"");
                Verb(cls, AllKeys[6], "Super Paste here", ico, q + " /paste \"%1\"");
            }
            Notify();
        }

        public static void Uninstall()
        {
            using (RegistryKey cls = Registry.CurrentUser.CreateSubKey(@"Software\Classes"))
            {
                for (int i = 0; i < AllKeys.Length; i++)
                {
                    try { cls.DeleteSubKeyTree(AllKeys[i]); } catch { }
                }
            }
            Notify();
        }

        static void Notify()
        {
            try { SHChangeNotify(0x08000000, 0, IntPtr.Zero, IntPtr.Zero); } catch { }
        }
    }

    // ================================================================
    //  Theme + drawing helpers (everything is drawn with GDI+, no images)
    // ================================================================
    static class Theme
    {
        public static readonly Color Bg = Color.FromArgb(20, 24, 40);
        public static readonly Color HeadA = Color.FromArgb(42, 50, 88);
        public static readonly Color HeadB = Color.FromArgb(26, 31, 54);
        public static readonly Color Panel = Color.FromArgb(30, 36, 60);
        public static readonly Color Panel2 = Color.FromArgb(46, 55, 92);
        public static readonly Color Row1 = Color.FromArgb(24, 29, 48);
        public static readonly Color Row2 = Color.FromArgb(29, 35, 58);
        public static readonly Color Sel = Color.FromArgb(52, 68, 118);
        public static readonly Color Text = Color.FromArgb(226, 231, 247);
        public static readonly Color Dim = Color.FromArgb(138, 148, 180);
        public static readonly Color Track = Color.FromArgb(13, 16, 30);
        public static readonly Color Border = Color.FromArgb(64, 75, 112);
        public static readonly Color Cyan = Color.FromArgb(0, 200, 255);
        public static readonly Color Violet = Color.FromArgb(150, 92, 255);
        public static readonly Color Green = Color.FromArgb(70, 220, 130);
        public static readonly Color Orange = Color.FromArgb(255, 170, 60);
        public static readonly Color Red = Color.FromArgb(255, 90, 100);

        public static readonly SolidBrush BrTrack = new SolidBrush(Track);
        public static readonly SolidBrush BrRow1 = new SolidBrush(Row1);
        public static readonly SolidBrush BrRow2 = new SolidBrush(Row2);
        public static readonly SolidBrush BrSel = new SolidBrush(Sel);
        public static readonly SolidBrush BrPanel = new SolidBrush(Panel);
        public static readonly SolidBrush BrGloss = new SolidBrush(Color.FromArgb(40, 255, 255, 255));

        public static readonly Font Cell = new Font("Tahoma", 8.25f);
        public static readonly Font Bold = new Font("Tahoma", 8.25f, FontStyle.Bold);
        public static readonly Font Title = new Font("Tahoma", 11f, FontStyle.Bold);
        public static readonly Font Big = new Font("Tahoma", 12f, FontStyle.Bold);

        // state: 0 pending, 1 copying, 2 done, 3 error, 4 skipped, 5 cancelled
        public static void BarColors(int state, bool paused, out Color a, out Color b)
        {
            switch (state)
            {
                case 1:
                    if (paused) { a = Orange; b = Color.FromArgb(255, 210, 110); }
                    else { a = Color.FromArgb(40, 110, 255); b = Cyan; }
                    break;
                case 2: a = Color.FromArgb(30, 170, 100); b = Color.FromArgb(120, 240, 160); break;
                case 3: a = Color.FromArgb(200, 40, 60); b = Color.FromArgb(255, 120, 100); break;
                case 4: a = Color.FromArgb(90, 95, 140); b = Color.FromArgb(150, 155, 200); break;
                case 5: a = Color.FromArgb(210, 120, 30); b = Color.FromArgb(255, 190, 90); break;
                default: a = Color.FromArgb(70, 80, 120); b = Color.FromArgb(90, 100, 140); break;
            }
        }
    }

    static class Fmt
    {
        public static string Size(long b)
        {
            if (b < 0) b = 0;
            if (b < 1024) return b + " B";
            double v = b / 1024.0;
            string[] u = new string[] { "KB", "MB", "GB", "TB" };
            int i = 0;
            while (v >= 1024 && i < 3) { v /= 1024; i++; }
            return v.ToString(v >= 100 ? "0" : (v >= 10 ? "0.0" : "0.00")) + " " + u[i];
        }

        public static string Time(double sec)
        {
            if (double.IsNaN(sec) || double.IsInfinity(sec) || sec < 0 || sec > 8640000) return "--:--";
            int s = (int)sec;
            int h = s / 3600, m = (s / 60) % 60, ss = s % 60;
            if (h > 0) return h + ":" + m.ToString("00") + ":" + ss.ToString("00");
            return m.ToString("00") + ":" + ss.ToString("00");
        }
    }

    static class Gfx
    {
        public static GraphicsPath Round(Rectangle r, int rad)
        {
            GraphicsPath p = new GraphicsPath();
            if (rad <= 0 || r.Width < rad * 2 || r.Height < rad * 2) { p.AddRectangle(r); return p; }
            int d = rad * 2;
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        // Colorful progress bar: rounded track, gradient fill, gloss, centered text.
        public static void Bar(Graphics g, Rectangle r, double frac, Color c1, Color c2,
                               string text, bool marquee, int tick, int rad)
        {
            if (r.Width < 6 || r.Height < 5) return;
            SmoothingMode old = g.SmoothingMode;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle tr = new Rectangle(r.X, r.Y, r.Width - 1, r.Height - 1);
            using (GraphicsPath path = Round(tr, rad))
            {
                g.FillPath(Theme.BrTrack, path);
                GraphicsState st = g.Save();
                g.SetClip(path, CombineMode.Intersect);

                Rectangle fr = Rectangle.Empty;
                if (marquee)
                {
                    int bw = Math.Max(30, tr.Width / 4);
                    int x = (tick * 16) % (tr.Width + bw) - bw;
                    fr = new Rectangle(tr.X + x, tr.Y, bw, tr.Height);
                }
                else
                {
                    if (frac < 0) frac = 0;
                    if (frac > 1) frac = 1;
                    int w = (int)Math.Round(tr.Width * frac);
                    if (w > 0) fr = new Rectangle(tr.X, tr.Y, w, tr.Height);
                }
                if (fr.Width > 0)
                {
                    Rectangle gr = marquee ? fr : tr;
                    using (LinearGradientBrush lb = new LinearGradientBrush(gr, c1, c2, LinearGradientMode.Horizontal))
                        g.FillRectangle(lb, fr);
                    g.FillRectangle(Theme.BrGloss, new Rectangle(fr.X, fr.Y, fr.Width, fr.Height / 2));
                }
                g.Restore(st);
                using (Pen p = new Pen(Theme.Border)) g.DrawPath(p, path);
            }
            g.SmoothingMode = old;

            if (text != null && text.Length > 0)
            {
                TextFormatFlags fl = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter |
                                     TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine;
                TextRenderer.DrawText(g, text, Theme.Bold, new Rectangle(r.X + 1, r.Y + 1, r.Width, r.Height), Color.FromArgb(0, 0, 0), fl);
                TextRenderer.DrawText(g, text, Theme.Bold, r, Color.White, fl);
            }
        }
    }

    static class IconMaker
    {
        public static Bitmap MakeBitmap(int size)
        {
            Bitmap b = new Bitmap(size, size, PixelFormat.Format32bppArgb);
            using (Graphics g = Graphics.FromImage(b))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);
                Rectangle r = new Rectangle(0, 0, size - 1, size - 1);
                using (GraphicsPath p = Gfx.Round(r, size / 4))
                using (LinearGradientBrush lb = new LinearGradientBrush(r, Theme.Cyan, Theme.Violet, 45f))
                    g.FillPath(lb, p);

                float s = size;
                PointF[] c1 = new PointF[] {
                    new PointF(.26f * s, .26f * s), new PointF(.50f * s, .50f * s), new PointF(.26f * s, .74f * s),
                    new PointF(.38f * s, .74f * s), new PointF(.62f * s, .50f * s), new PointF(.38f * s, .26f * s) };
                PointF[] c2 = new PointF[c1.Length];
                for (int i = 0; i < c1.Length; i++) c2[i] = new PointF(c1[i].X + .16f * s, c1[i].Y);
                g.FillPolygon(Brushes.White, c1);
                g.FillPolygon(Brushes.White, c2);
            }
            return b;
        }

        public static Icon MakeIcon()
        {
            using (Bitmap b = MakeBitmap(32))
                return Icon.FromHandle(b.GetHicon());
        }

        // writes a classic 32x32 32-bit .ico (works on XP too)
        public static void WriteIco(string path)
        {
            const int s = 32;
            using (Bitmap bmp = MakeBitmap(s))
            using (FileStream fs = new FileStream(path, FileMode.Create))
            using (BinaryWriter w = new BinaryWriter(fs))
            {
                int maskRow = ((s + 31) / 32) * 4;
                int imgSize = 40 + s * s * 4 + maskRow * s;
                w.Write((short)0); w.Write((short)1); w.Write((short)1);                 // ICONDIR
                w.Write((byte)s); w.Write((byte)s); w.Write((byte)0); w.Write((byte)0);  // ICONDIRENTRY
                w.Write((short)1); w.Write((short)32); w.Write(imgSize); w.Write(22);
                w.Write(40); w.Write(s); w.Write(s * 2); w.Write((short)1); w.Write((short)32);  // BITMAPINFOHEADER
                w.Write(0); w.Write(s * s * 4); w.Write(0); w.Write(0); w.Write(0); w.Write(0);
                for (int y = s - 1; y >= 0; y--)
                    for (int x = 0; x < s; x++)
                    {
                        Color c = bmp.GetPixel(x, y);
                        w.Write(c.B); w.Write(c.G); w.Write(c.R); w.Write(c.A);
                    }
                for (int i = 0; i < maskRow * s; i++) w.Write((byte)0);
            }
        }
    }

    // ================================================================
    //  Copy engine
    // ================================================================
    class CopyItem
    {
        public string Src, Dst, Name, Error;
        public long Size;
        public long Done;                 // bytes copied (Interlocked)
        public volatile int State;        // 0 pending, 1 copying, 2 done, 3 error, 4 skipped, 5 cancelled
        public int Index;
        public double Speed;              // bytes/s (UI thread)
        public long SampBytes;

        public double Fraction
        {
            get
            {
                if (State == 2 || State == 4) return 1.0;
                if (Size <= 0) return 0.0;
                double f = (double)Interlocked.Read(ref Done) / Size;
                return f > 1 ? 1 : (f < 0 ? 0 : f);
            }
        }
    }

    class CopyJob
    {
        public readonly List<string> Sources;
        public readonly string Dest;
        public readonly bool Move;
        public readonly string Summary;

        readonly List<CopyItem> items = new List<CopyItem>();
        readonly List<CopyItem> active = new List<CopyItem>();
        readonly List<string> srcDirs = new List<string>();
        readonly object sync = new object();
        readonly object activeLock = new object();

        public long TotalBytes, DoneBytes;
        public int Errors, FilesDone;
        public volatile bool ScanDone, Paused, Cancelled, Finished, Started;
        public string LastError;
        public double Speed;
        public int ActiveMs;
        long lastDone;
        int next, workers;

        public CopyJob(List<string> sources, string dest, bool move)
        {
            Sources = sources; Dest = dest; Move = move;
            string first = Path.GetFileName(sources[0].TrimEnd('\\', '/'));
            if (first == null || first.Length == 0) first = sources[0];
            string what = sources.Count == 1 ? "\"" + first + "\"" : sources.Count + " items";
            Summary = what + " to " + dest;
        }

        public long Total { get { return Interlocked.Read(ref TotalBytes); } }
        public long DoneNow { get { return Interlocked.Read(ref DoneBytes); } }

        public int ItemCount { get { lock (sync) { return items.Count; } } }

        public CopyItem GetItem(int i)
        {
            lock (sync) { return (i >= 0 && i < items.Count) ? items[i] : null; }
        }

        public double Fraction
        {
            get
            {
                long t = Total;
                if (t <= 0) return Finished ? 1.0 : 0.0;
                double f = (double)DoneNow / t;
                return f > 1 ? 1 : (f < 0 ? 0 : f);
            }
        }

        public double Eta
        {
            get
            {
                if (Speed < 1) return -1;
                return (Total - DoneNow) / Speed;
            }
        }

        public int FirstActiveIndex()
        {
            int min = -1;
            lock (activeLock)
            {
                for (int i = 0; i < active.Count; i++)
                    if (min < 0 || active[i].Index < min) min = active[i].Index;
            }
            return min;
        }

        // ---------- control ----------
        public void Start()
        {
            Started = true;
            int n = Math.Max(1, Math.Min(8, Settings.Concurrency));
            lock (sync) { workers += n; }
            Thread st = new Thread(new ThreadStart(ScanMain), 256 * 1024);
            st.IsBackground = true;
            st.Start();
            for (int i = 0; i < n; i++) SpawnWorker();
        }

        void SpawnWorker()
        {
            Thread t = new Thread(new ThreadStart(WorkerMain), 256 * 1024);
            t.IsBackground = true;
            t.Start();
        }

        // lets the "concurrent copies" setting grow while a job is running
        public void EnsureWorkers()
        {
            if (!Started || Finished || Cancelled) return;
            bool spawn = false;
            lock (sync)
            {
                if (workers > 0 && workers < Settings.Concurrency && next < items.Count)
                {
                    workers++;
                    spawn = true;
                }
            }
            if (spawn) SpawnWorker();
        }

        public void Cancel()
        {
            Cancelled = true;
            if (!Started) { Started = true; ScanDone = true; Finished = true; }
        }

        // called from the UI timer: speed + per-file speed + active time
        public void Sample(int dt)
        {
            long done = DoneNow;
            if (Paused) Speed = 0;
            else
            {
                double inst = (done - lastDone) * 1000.0 / dt;
                double a = 1.0 - Math.Exp(-dt / 1500.0);
                Speed = Speed <= 0 ? inst : Speed + (inst - Speed) * a;
                ActiveMs += dt;
            }
            lastDone = done;

            CopyItem[] arr;
            lock (activeLock) { arr = active.ToArray(); }
            double ai = 1.0 - Math.Exp(-dt / 1000.0);
            for (int i = 0; i < arr.Length; i++)
            {
                CopyItem it = arr[i];
                long d = Interlocked.Read(ref it.Done);
                if (Paused) it.Speed = 0;
                else
                {
                    double v = (d - it.SampBytes) * 1000.0 / dt;
                    it.Speed = it.Speed <= 0 ? v : it.Speed + (v - it.Speed) * ai;
                }
                it.SampBytes = d;
            }
        }

        // ---------- helpers ----------
        static string Norm(string p)
        {
            try { return Path.GetFullPath(p).TrimEnd('\\', '/'); } catch { return p.TrimEnd('\\', '/'); }
        }
        static bool SamePath(string a, string b)
        {
            return string.Equals(Norm(a), Norm(b), StringComparison.OrdinalIgnoreCase);
        }
        static bool IsSubOrSame(string path, string parent)
        {
            string a = Norm(path), b = Norm(parent);
            return a.Equals(b, StringComparison.OrdinalIgnoreCase) ||
                   a.StartsWith(b + "\\", StringComparison.OrdinalIgnoreCase);
        }
        static bool SameRoot(string a, string b)
        {
            try
            {
                return string.Equals(Path.GetPathRoot(Path.GetFullPath(a)), Path.GetPathRoot(Path.GetFullPath(b)),
                                     StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }
        static string UniqueFile(string path)
        {
            string dir = Path.GetDirectoryName(path);
            string nm = Path.GetFileNameWithoutExtension(path);
            string ext = Path.GetExtension(path);
            for (int n = 2; n < 100000; n++)
            {
                string c = Path.Combine(dir, nm + " (" + n + ")" + ext);
                if (!File.Exists(c) && !Directory.Exists(c)) return c;
            }
            return path;
        }
        static string UniqueDir(string parent, string name)
        {
            string c = Path.Combine(parent, name);
            for (int n = 2; (Directory.Exists(c) || File.Exists(c)) && n < 100000; n++)
                c = Path.Combine(parent, name + " (" + n + ")");
            return c;
        }

        // ---------- scanner thread ----------
        void AddFile(string src, string dst, string name)
        {
            long size = 0;
            try { size = new FileInfo(src).Length; } catch { }
            CopyItem it = new CopyItem();
            it.Src = src; it.Dst = dst; it.Name = name; it.Size = size;
            lock (sync) { it.Index = items.Count; items.Add(it); }
            Interlocked.Add(ref TotalBytes, size);
        }

        void AddFinished(string name, int state, string msg)
        {
            CopyItem it = new CopyItem();
            it.Name = name; it.State = state; it.Error = msg;
            lock (sync) { it.Index = items.Count; items.Add(it); }
            Interlocked.Increment(ref FilesDone);
            if (state == 3) { Interlocked.Increment(ref Errors); LastError = name + ": " + msg; }
        }

        void ScanDir(string src, string dst, string rel)
        {
            if (Cancelled) return;
            Directory.CreateDirectory(dst);
            if (Move) lock (sync) { srcDirs.Add(src); }

            string[] files;
            try { files = Directory.GetFiles(src); }
            catch (Exception ex) { AddFinished(rel, 3, ex.Message); files = new string[0]; }
            for (int i = 0; i < files.Length; i++)
            {
                if (Cancelled) return;
                string fn = Path.GetFileName(files[i]);
                AddFile(files[i], Path.Combine(dst, fn), rel + "\\" + fn);
            }

            string[] dirs;
            try { dirs = Directory.GetDirectories(src); }
            catch (Exception ex) { AddFinished(rel, 3, ex.Message); dirs = new string[0]; }
            for (int i = 0; i < dirs.Length; i++)
            {
                if (Cancelled) return;
                try { if ((File.GetAttributes(dirs[i]) & FileAttributes.ReparsePoint) != 0) continue; } catch { }
                string dn = Path.GetFileName(dirs[i]);
                ScanDir(dirs[i], Path.Combine(dst, dn), rel + "\\" + dn);
            }
        }

        void ScanMain()
        {
            try
            {
                foreach (string src in Sources)
                {
                    if (Cancelled) break;
                    try
                    {
                        if (Directory.Exists(src))
                        {
                            string name = Path.GetFileName(src.TrimEnd('\\', '/'));
                            if (name == null || name.Length == 0) name = src.Replace(":", "").Replace("\\", "");
                            if (IsSubOrSame(Dest, src))
                            {
                                AddFinished(name, 3, "Destination is inside the source folder");
                                continue;
                            }
                            string target = Path.Combine(Dest, name);
                            if (SamePath(target, src))
                            {
                                if (Move) { AddFinished(name, 4, "Same folder"); continue; }
                                target = UniqueDir(Dest, name + " - Copy");
                            }
                            ScanDir(src, target, name);
                        }
                        else if (File.Exists(src))
                        {
                            string fn = Path.GetFileName(src);
                            AddFile(src, Path.Combine(Dest, fn), fn);
                        }
                        else AddFinished(src, 3, "Not found");
                    }
                    catch (Exception ex) { AddFinished(src, 3, ex.Message); }
                }
            }
            finally { ScanDone = true; }
        }

        // ---------- worker threads ----------
        void WorkerMain()
        {
            byte[] buf = null;
            bool last = false;
            while (true)
            {
                CopyItem it = null;
                bool wait = false;
                lock (sync)
                {
                    if (Cancelled) { workers--; last = (workers == 0); break; }
                    if (workers > Settings.Concurrency) { workers--; return; }
                    if (next < items.Count) it = items[next++];
                    else if (ScanDone) { workers--; last = (workers == 0); break; }
                    else wait = true;
                }
                if (wait) { Thread.Sleep(25); continue; }

                int want = Settings.BufferKB * 1024;
                if (buf == null || buf.Length != want) buf = new byte[want];
                ProcessItem(it, buf);
            }
            if (last) OnFinished();
        }

        void ProcessItem(CopyItem it, byte[] buf)
        {
            if (it.State != 0) return;
            it.Speed = 0; it.SampBytes = 0;
            it.State = 1;
            lock (activeLock) { active.Add(it); }
            try { DoCopy(it, buf); }
            catch (Exception ex)
            {
                it.State = 3; it.Error = ex.Message;
                LastError = it.Name + ": " + ex.Message;
                Interlocked.Increment(ref Errors);
                long rem = it.Size - Interlocked.Read(ref it.Done);
                if (rem > 0) Interlocked.Add(ref DoneBytes, rem);
            }
            finally
            {
                lock (activeLock) { active.Remove(it); }
                Interlocked.Increment(ref FilesDone);
            }
        }

        void Skip(CopyItem it)
        {
            Interlocked.Add(ref DoneBytes, it.Size);
            it.Done = it.Size;
            it.State = 4;
        }

        void DoCopy(CopyItem it, byte[] buf)
        {
            string src = it.Src, dst = it.Dst;

            if (File.Exists(dst))
            {
                if (SamePath(src, dst))
                {
                    if (Move) { Skip(it); return; }
                    dst = UniqueFile(dst);
                }
                else
                {
                    int c = Settings.Conflict;
                    if (c == 1) { Skip(it); return; }
                    if (c == 2) dst = UniqueFile(dst);
                    else if (c == 3 && File.GetLastWriteTime(src) <= File.GetLastWriteTime(dst)) { Skip(it); return; }
                    else File.SetAttributes(dst, FileAttributes.Normal);   // overwrite: clear read-only
                }
                it.Dst = dst;
            }

            // same drive + move = instant rename
            if (Move && SameRoot(src, dst))
            {
                if (File.Exists(dst)) File.Delete(dst);
                File.Move(src, dst);
                Interlocked.Add(ref DoneBytes, it.Size);
                it.Done = it.Size;
                it.State = 2;
                return;
            }

            bool ok = CopyData(src, dst, it, buf);
            if (!ok)
            {
                try { File.Delete(dst); } catch { }
                it.State = 5;
                return;
            }

            long d = Interlocked.Read(ref it.Done);
            if (d != it.Size) { Interlocked.Add(ref TotalBytes, d - it.Size); it.Size = d; }

            try
            {
                File.SetCreationTime(dst, File.GetCreationTime(src));
                File.SetLastWriteTime(dst, File.GetLastWriteTime(src));
                File.SetAttributes(dst, File.GetAttributes(src));
            }
            catch { }

            if (Move)
            {
                try { File.SetAttributes(src, FileAttributes.Normal); File.Delete(src); }
                catch (Exception ex)
                {
                    it.Error = "Copied, source not deleted: " + ex.Message;
                    LastError = it.Name + ": " + it.Error;
                    it.State = 3;
                    Interlocked.Increment(ref Errors);
                    return;
                }
            }
            it.State = 2;
        }

        // returns false when cancelled
        bool CopyData(string src, string dst, CopyItem it, byte[] buf)
        {
            FileStream fi = null, fo = null;
            bool ok = false;
            try
            {
                fi = new FileStream(src, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 4096, FileOptions.SequentialScan);
                fo = new FileStream(dst, FileMode.Create, FileAccess.Write, FileShare.None, 4096, FileOptions.SequentialScan);
                int n;
                while ((n = fi.Read(buf, 0, buf.Length)) > 0)
                {
                    while (Paused && !Cancelled) Thread.Sleep(100);
                    if (Cancelled) break;
                    fo.Write(buf, 0, n);
                    Interlocked.Add(ref it.Done, n);
                    Interlocked.Add(ref DoneBytes, n);
                }
                ok = !Cancelled;
            }
            catch
            {
                if (fi != null) { try { fi.Close(); } catch { } }
                if (fo != null)
                {
                    try { fo.Close(); } catch { }
                    try { File.Delete(dst); } catch { }   // remove the partial file we created
                }
                throw;
            }
            if (fi != null) fi.Close();
            if (fo != null) fo.Close();
            return ok;
        }

        void OnFinished()
        {
            try
            {
                if (Move && !Cancelled && Errors == 0)
                {
                    // children were added after parents, so walk backwards; only empty folders go away
                    for (int i = srcDirs.Count - 1; i >= 0; i--)
                    {
                        try { Directory.Delete(srcDirs[i], false); } catch { }
                    }
                }
                lock (sync)
                {
                    for (int i = next; i < items.Count; i++)
                        if (items[i].State == 0) items[i].State = 5;
                }
            }
            catch { }
            Finished = true;
        }
    }

    // ================================================================
    //  UI controls
    // ================================================================
    class BufferedListView : ListView
    {
        [DllImport("user32.dll")]
        static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

        public BufferedListView()
        {
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try { SendMessage(Handle, 0x1036, (IntPtr)0x10000, (IntPtr)0x10000); } catch { }  // LVS_EX_DOUBLEBUFFER
        }
    }

    class HeaderPanel : Panel
    {
        public string Title = "", Elapsed = "0:00", BarText = "", TxtL = "", TxtM = "", TxtR = "";
        public double Frac;
        public bool Marquee;
        public int Tick;
        public Color ColA = Theme.Cyan, ColB = Theme.Violet;
        public Button HideButton;

        public HeaderPanel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            if (HideButton != null) HideButton.Location = new Point(Width - HideButton.Width - 14, 9);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            if (Width < 60 || Height < 40) return;
            Rectangle rc = ClientRectangle;
            using (LinearGradientBrush lb = new LinearGradientBrush(rc, Theme.HeadA, Theme.HeadB, 90f))
                g.FillRectangle(lb, rc);
            using (LinearGradientBrush ab = new LinearGradientBrush(new Rectangle(0, Height - 3, Width, 3), Theme.Cyan, Theme.Violet, 0f))
                g.FillRectangle(ab, 0, Height - 3, Width, 3);

            int hideLeft = HideButton != null ? HideButton.Left : Width - 90;
            Rectangle timeR = new Rectangle(hideLeft - 118, 10, 110, 24);
            Rectangle titleR = new Rectangle(14, 10, Math.Max(40, timeR.Left - 24), 24);
            TextRenderer.DrawText(g, Title, Theme.Title, titleR, Theme.Text,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine);
            TextRenderer.DrawText(g, Elapsed, Theme.Big, timeR, Theme.Cyan,
                TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine);

            Rectangle bar = new Rectangle(14, 42, Width - 28, 26);
            Gfx.Bar(g, bar, Frac, ColA, ColB, BarText, Marquee, Tick, 8);

            Rectangle sr = new Rectangle(14, 74, Width - 28, 20);
            TextRenderer.DrawText(g, TxtL, Theme.Bold, sr, Theme.Text,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine);
            TextRenderer.DrawText(g, TxtM, Theme.Bold, sr, Theme.Text,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine);
            TextRenderer.DrawText(g, TxtR, Theme.Cell, sr, Theme.Dim,
                TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine);
        }
    }

    class TitleBar : Panel
    {
        public string Title = "", Sub = "";

        public TitleBar()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            if (Width < 20 || Height < 10) return;
            using (LinearGradientBrush lb = new LinearGradientBrush(ClientRectangle, Theme.Cyan, Theme.Violet, 0f))
                g.FillRectangle(lb, ClientRectangle);
            g.DrawImage(IconMaker.MakeBitmap(32), 14, (Height - 32) / 2);
            TextRenderer.DrawText(g, Title, Theme.Title, new Rectangle(56, 8, Width - 60, 22), Color.White,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
            TextRenderer.DrawText(g, Sub, Theme.Cell, new Rectangle(56, 30, Width - 60, 18), Color.FromArgb(230, 235, 255),
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        }
    }

    static class UI
    {
        public static Button MakeButton(string text, int w, Color back)
        {
            Button b = new Button();
            b.Text = text;
            b.Size = new Size(w, 28);
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.UseVisualStyleBackColor = false;
            b.BackColor = back;
            b.FlatAppearance.MouseOverBackColor = Color.FromArgb(
                Math.Min(255, back.R + 35), Math.Min(255, back.G + 35), Math.Min(255, back.B + 35));
            b.ForeColor = Color.White;
            b.Font = Theme.Bold;
            b.Cursor = Cursors.Hand;
            return b;
        }
    }

    // ================================================================
    //  Progress window
    // ================================================================
    class MainForm : Form
    {
        readonly List<CopyJob> jobs = new List<CopyJob>();
        CopyJob cur, running;
        HeaderPanel header;
        BufferedListView lv;
        ListBox jobBox;
        Panel bottom;
        Button btnPause, btnCancel, btnSettings, btnHide;
        CheckBox chkClose;
        Label lblErr;
        System.Windows.Forms.Timer timer;
        NotifyIcon tray;
        bool exiting, doneHandled, settingSel;
        int lastTick, tickN, closeAt = -1;

        const TextFormatFlags CellFlags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter |
            TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine;

        public MainForm(CopyJob first)
        {
            Text = "Super Copy";
            Font = Theme.Cell;
            BackColor = Theme.Bg;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(800, 520);
            MinimumSize = new Size(660, 380);
            Icon = IconMaker.MakeIcon();

            // ----- file list -----
            lv = new BufferedListView();
            lv.Dock = DockStyle.Fill;
            lv.View = View.Details;
            lv.VirtualMode = true;
            lv.OwnerDraw = true;
            lv.FullRowSelect = true;
            lv.HideSelection = false;
            lv.MultiSelect = false;
            lv.BorderStyle = BorderStyle.None;
            lv.BackColor = Theme.Row1;
            lv.ForeColor = Theme.Text;
            lv.Columns.Add("File", 300);
            lv.Columns.Add("Size", 80);
            lv.Columns.Add("Progress", 150);
            lv.Columns.Add("Speed", 85);
            lv.Columns.Add("ETA", 65);
            lv.Columns.Add("Status", 120);
            ImageList rowH = new ImageList();      // trick: taller rows for the progress bars
            rowH.ImageSize = new Size(1, 24);
            lv.SmallImageList = rowH;
            lv.RetrieveVirtualItem += new RetrieveVirtualItemEventHandler(lv_Retrieve);
            lv.DrawColumnHeader += new DrawListViewColumnHeaderEventHandler(lv_DrawHeader);
            lv.DrawItem += new DrawListViewItemEventHandler(lv_DrawItem);
            lv.DrawSubItem += new DrawListViewSubItemEventHandler(lv_DrawSub);
            lv.Resize += new EventHandler(lv_Resize);

            // ----- bottom bar -----
            bottom = new Panel();
            bottom.Dock = DockStyle.Bottom;
            bottom.Height = 46;
            bottom.BackColor = Theme.Panel;
            btnPause = UI.MakeButton("Pause", 78, Color.FromArgb(214, 140, 30));
            btnCancel = UI.MakeButton("Cancel", 78, Color.FromArgb(200, 55, 75));
            btnSettings = UI.MakeButton("Settings", 84, Color.FromArgb(70, 90, 170));
            btnPause.Location = new Point(12, 9);
            btnCancel.Location = new Point(98, 9);
            btnSettings.Location = new Point(184, 9);
            chkClose = new CheckBox();
            chkClose.Text = "Close when finished";
            chkClose.AutoSize = true;
            chkClose.ForeColor = Theme.Text;
            chkClose.BackColor = Theme.Panel;
            chkClose.Location = new Point(284, 14);
            chkClose.Checked = Settings.AutoClose;
            chkClose.CheckedChanged += new EventHandler(chkClose_Changed);
            lblErr = new Label();
            lblErr.AutoSize = false;
            lblErr.AutoEllipsis = true;
            lblErr.ForeColor = Theme.Red;
            lblErr.BackColor = Theme.Panel;
            lblErr.TextAlign = ContentAlignment.MiddleRight;
            lblErr.SetBounds(440, 14, 300, 18);
            bottom.Controls.Add(btnPause);
            bottom.Controls.Add(btnCancel);
            bottom.Controls.Add(btnSettings);
            bottom.Controls.Add(chkClose);
            bottom.Controls.Add(lblErr);
            bottom.Resize += new EventHandler(bottom_Resize);
            btnPause.Click += new EventHandler(btnPause_Click);
            btnCancel.Click += new EventHandler(btnCancel_Click);
            btnSettings.Click += new EventHandler(btnSettings_Click);

            // ----- job strip (visible when more than one operation is queued) -----
            jobBox = new ListBox();
            jobBox.Dock = DockStyle.Top;
            jobBox.DrawMode = DrawMode.OwnerDrawFixed;
            jobBox.ItemHeight = 26;
            jobBox.IntegralHeight = false;
            jobBox.BorderStyle = BorderStyle.None;
            jobBox.BackColor = Theme.Panel;
            jobBox.Visible = false;
            jobBox.DrawItem += new DrawItemEventHandler(jobBox_DrawItem);
            jobBox.SelectedIndexChanged += new EventHandler(jobBox_Changed);

            // ----- header -----
            header = new HeaderPanel();
            header.Dock = DockStyle.Top;
            header.Height = 104;
            btnHide = UI.MakeButton("Hide", 70, Color.FromArgb(70, 90, 170));
            btnHide.Height = 26;
            header.HideButton = btnHide;
            header.Controls.Add(btnHide);
            btnHide.Location = new Point(header.Width - btnHide.Width - 14, 9);
            btnHide.Click += new EventHandler(btnHide_Click);

            // docking order: fill first, outermost (top-most) last
            Controls.Add(lv);
            Controls.Add(bottom);
            Controls.Add(jobBox);
            Controls.Add(header);

            // ----- tray icon (for "Hide") -----
            tray = new NotifyIcon();
            tray.Icon = Icon;
            tray.Text = "Super Copy";
            tray.Visible = false;
            tray.DoubleClick += new EventHandler(tray_Show);
            ContextMenu cm = new ContextMenu();
            cm.MenuItems.Add("Show window", new EventHandler(tray_Show));
            cm.MenuItems.Add("Pause / Resume", new EventHandler(btnPause_Click));
            cm.MenuItems.Add("-");
            cm.MenuItems.Add("Cancel all and exit", new EventHandler(tray_Exit));
            tray.ContextMenu = cm;

            AddJob(first);

            timer = new System.Windows.Forms.Timer();
            timer.Interval = 250;
            timer.Tick += new EventHandler(OnTick);
            lastTick = Environment.TickCount;
            timer.Start();

            lv_Resize(null, null);
            bottom_Resize(null, null);
        }

        // ------------------------------------------------------------
        void AddJob(CopyJob j)
        {
            jobs.Add(j);
            jobBox.Items.Add(j);
            doneHandled = false;
            closeAt = -1;
            bool multi = jobs.Count >= 2;
            jobBox.Visible = multi;
            jobBox.Height = Math.Min(jobs.Count, 4) * 26 + 2;
            if (cur == null) SetCur(j);
        }

        void SetCur(CopyJob j)
        {
            cur = j;
            lv.VirtualListSize = j.ItemCount;
            lv.Invalidate();
            int idx = jobs.IndexOf(j);
            if (idx >= 0 && jobBox.SelectedIndex != idx)
            {
                bool old = settingSel;
                settingSel = true;
                jobBox.SelectedIndex = idx;
                settingSel = old;
            }
        }

        void PollQueue()
        {
            string[] fs;
            try { fs = Directory.GetFiles(Paths.QueueDir, "*.job"); } catch { return; }
            if (fs.Length == 0) return;
            Array.Sort(fs);
            for (int k = 0; k < fs.Length; k++)
            {
                try
                {
                    string[] ln = File.ReadAllLines(fs[k], Encoding.UTF8);
                    File.Delete(fs[k]);
                    if (ln.Length >= 3)
                    {
                        List<string> src = new List<string>();
                        for (int i = 2; i < ln.Length; i++) if (ln[i].Length > 0) src.Add(ln[i]);
                        if (src.Count > 0) AddJob(new CopyJob(src, ln[1], ln[0] == "cut"));
                    }
                }
                catch { }
            }
        }

        bool AnyRunning()
        {
            for (int i = 0; i < jobs.Count; i++) if (!jobs[i].Finished) return true;
            return false;
        }

        bool MouseInList()
        {
            try { return lv.ClientRectangle.Contains(lv.PointToClient(Cursor.Position)); } catch { return false; }
        }

        // ------------------------------------------------------------
        //  timer: sampling, scheduling, refresh
        // ------------------------------------------------------------
        void OnTick(object sender, EventArgs e)
        {
            tickN++;
            int now = Environment.TickCount;
            int dt = now - lastTick;
            lastTick = now;
            if (dt < 1) dt = 1;

            if (tickN % 2 == 0) PollQueue();
            if (running != null && !running.Finished)
            {
                running.EnsureWorkers();
                running.Sample(dt);
            }
            Advance();

            // caption / tray tooltip stay current even when hidden
            string cap = "Super Copy";
            if (cur != null && cur.Started && !cur.Finished) cap = ((int)(cur.Fraction * 100)) + "% - Super Copy";
            if (Text != cap) Text = cap;
            if (tray.Visible && tray.Text != cap) tray.Text = cap;

            if (Visible && WindowState != FormWindowState.Minimized && cur != null)
            {
                int cnt = cur.ItemCount;
                if (lv.VirtualListSize != cnt) lv.VirtualListSize = cnt;
                if (cur == running && !cur.Finished && cnt > 0 && !MouseInList())
                {
                    int idx = cur.FirstActiveIndex();
                    if (idx >= 0)
                    {
                        try
                        {
                            lv.EnsureVisible(Math.Min(cnt - 1, idx + 8));
                            lv.EnsureVisible(idx);
                        }
                        catch { }
                    }
                }
                UpdateHeader();
                UpdateButtons();
                header.Tick = tickN;
                header.Invalidate();
                lv.Invalidate();
                if (jobBox.Visible) jobBox.Invalidate();
            }

            if (closeAt >= 0 && tickN >= closeAt) { exiting = true; Close(); }
        }

        void Advance()
        {
            if (running == null || running.Finished)
            {
                CopyJob nx = null;
                for (int i = 0; i < jobs.Count; i++)
                    if (!jobs[i].Started) { nx = jobs[i]; break; }
                if (nx != null)
                {
                    running = nx;
                    nx.Start();
                    SetCur(nx);
                    doneHandled = false;
                    closeAt = -1;
                }
                else if (!doneHandled && running != null)
                {
                    doneHandled = true;
                    AllDone();
                }
            }
        }

        void AllDone()
        {
            int errs = 0;
            bool canc = false;
            for (int i = 0; i < jobs.Count; i++) { errs += jobs[i].Errors; canc = canc || jobs[i].Cancelled; }
            if (errs > 0 || canc)
            {
                if (!Visible) ShowFromTray();     // let the user see what happened
            }
            else if (Settings.AutoClose)
            {
                closeAt = tickN + 6;
            }
            else if (!Visible)
            {
                try { tray.ShowBalloonTip(3000, "Super Copy", "All operations completed.", ToolTipIcon.Info); } catch { }
            }
        }

        void UpdateHeader()
        {
            CopyJob j = cur;
            HeaderPanel h = header;
            long total = j.Total, done = j.DoneNow;
            int files = j.ItemCount;
            string errs = j.Errors > 0 ? "    Errors: " + j.Errors : "";
            string filesTxt = j.FilesDone + " / " + files + (j.ScanDone ? "" : "+") + " files    " +
                              Fmt.Size(done) + " / " + Fmt.Size(total) + (j.ScanDone ? "" : "+") + errs;
            string verb = j.Move ? "Moving " : "Copying ";
            h.Elapsed = Fmt.Time(j.ActiveMs / 1000.0);
            h.Marquee = false;
            h.Frac = j.Fraction;
            h.TxtR = filesTxt;

            if (!j.Started)
            {
                h.Title = "Queued: " + j.Summary;
                h.BarText = "Waiting...";
                h.Frac = 0;
                h.ColA = Color.FromArgb(70, 80, 120); h.ColB = Color.FromArgb(100, 110, 150);
                h.TxtL = "Speed: -"; h.TxtM = "Total ETA: -";
            }
            else if (j.Finished)
            {
                if (j.Cancelled)
                {
                    h.Title = "Cancelled: " + j.Summary;
                    h.ColA = Color.FromArgb(210, 120, 30); h.ColB = Color.FromArgb(255, 190, 90);
                }
                else if (j.Errors > 0)
                {
                    h.Title = "Finished with errors: " + j.Summary;
                    h.Frac = 1.0;
                    h.ColA = Color.FromArgb(200, 40, 60); h.ColB = Color.FromArgb(255, 120, 100);
                }
                else
                {
                    h.Title = "Completed: " + j.Summary;
                    h.Frac = 1.0;
                    h.ColA = Color.FromArgb(30, 170, 100); h.ColB = Color.FromArgb(120, 240, 160);
                }
                h.BarText = ((int)Math.Round(h.Frac * 100)) + "%";
                double avg = j.ActiveMs > 0 ? done * 1000.0 / j.ActiveMs : 0;
                h.TxtL = "Average speed: " + Fmt.Size((long)avg) + "/s";
                h.TxtM = "Total time: " + Fmt.Time(j.ActiveMs / 1000.0);
            }
            else
            {
                bool paused = j.Paused;
                h.Title = (paused ? "Paused - " : verb) + j.Summary;
                if (!j.ScanDone)
                {
                    h.Marquee = true;
                    h.BarText = "Scanning folders...  " + files + " files found";
                }
                else h.BarText = (h.Frac * 100).ToString("0.0") + "%";
                if (paused) { h.ColA = Theme.Orange; h.ColB = Color.FromArgb(255, 210, 110); }
                else { h.ColA = Theme.Cyan; h.ColB = Theme.Violet; }
                h.TxtL = paused ? "Speed: paused" : "Speed: " + Fmt.Size((long)j.Speed) + "/s";
                h.TxtM = paused ? "Total ETA: -" :
                         (j.ScanDone ? "Total ETA: " + Fmt.Time(j.Eta) : "Total ETA: calculating...");
            }
            lblErr.Text = j.LastError == null ? "" : "Last error: " + j.LastError;
        }

        void UpdateButtons()
        {
            bool active = cur != null && !cur.Finished;
            btnPause.Enabled = active;
            btnCancel.Enabled = active;
            string t = (cur != null && cur.Paused) ? "Resume" : "Pause";
            if (btnPause.Text != t) btnPause.Text = t;
        }

        // ------------------------------------------------------------
        //  events
        // ------------------------------------------------------------
        void btnPause_Click(object s, EventArgs e)
        {
            if (cur != null && !cur.Finished) cur.Paused = !cur.Paused;
        }

        void btnCancel_Click(object s, EventArgs e)
        {
            if (cur != null && !cur.Finished) cur.Cancel();
        }

        void btnSettings_Click(object s, EventArgs e)
        {
            using (SettingsForm f = new SettingsForm()) f.ShowDialog(this);
            chkClose.Checked = Settings.AutoClose;
        }

        void btnHide_Click(object s, EventArgs e) { HideToTray(); }

        void chkClose_Changed(object s, EventArgs e)
        {
            Settings.AutoClose = chkClose.Checked;
            Settings.Save();
        }

        void HideToTray()
        {
            tray.Visible = true;
            Hide();
        }

        void ShowFromTray()
        {
            Show();
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            Activate();
            tray.Visible = false;
        }

        void tray_Show(object s, EventArgs e) { ShowFromTray(); }

        void tray_Exit(object s, EventArgs e) { exiting = true; Close(); }

        void bottom_Resize(object s, EventArgs e)
        {
            int x = chkClose.Right + 14;
            lblErr.SetBounds(x, 14, Math.Max(40, bottom.ClientSize.Width - x - 12), 18);
        }

        void lv_Resize(object s, EventArgs e)
        {
            int others = 0;
            for (int i = 1; i < lv.Columns.Count; i++) others += lv.Columns[i].Width;
            int w = lv.ClientSize.Width - others;
            if (w < 120) w = 120;
            if (lv.Columns[0].Width != w) lv.Columns[0].Width = w;
        }

        void jobBox_Changed(object s, EventArgs e)
        {
            if (settingSel) return;
            int i = jobBox.SelectedIndex;
            if (i >= 0 && i < jobs.Count) SetCur(jobs[i]);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (!exiting && AnyRunning())
            {
                DialogResult r = MessageBox.Show(this,
                    "Copy operations are still running.\n\nYes = cancel and exit\nNo = hide to the tray and keep copying",
                    "Super Copy", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (r == DialogResult.Cancel) { e.Cancel = true; return; }
                if (r == DialogResult.No) { e.Cancel = true; HideToTray(); return; }
            }
            if (AnyRunning())
            {
                for (int i = 0; i < jobs.Count; i++) jobs[i].Cancel();
                int t0 = Environment.TickCount;
                while (Environment.TickCount - t0 < 3000)
                {
                    bool all = true;
                    for (int i = 0; i < jobs.Count; i++) if (!jobs[i].Finished) all = false;
                    if (all) break;
                    Thread.Sleep(30);
                }
            }
            timer.Stop();
            tray.Visible = false;
            tray.Dispose();
            base.OnFormClosing(e);
        }

        // ------------------------------------------------------------
        //  owner-drawn file list
        // ------------------------------------------------------------
        void lv_Retrieve(object s, RetrieveVirtualItemEventArgs e)
        {
            e.Item = new ListViewItem(new string[] { "", "", "", "", "", "" });
        }

        void lv_DrawHeader(object s, DrawListViewColumnHeaderEventArgs e)
        {
            Rectangle r = e.Bounds;
            if (r.Width <= 0 || r.Height <= 0) return;
            using (LinearGradientBrush lb = new LinearGradientBrush(r, Theme.Panel2, Theme.Panel, 90f))
                e.Graphics.FillRectangle(lb, r);
            using (Pen p = new Pen(Theme.Border))
            {
                e.Graphics.DrawLine(p, r.Right - 1, r.Top + 4, r.Right - 1, r.Bottom - 5);
                e.Graphics.DrawLine(p, r.Left, r.Bottom - 1, r.Right, r.Bottom - 1);
            }
            TextRenderer.DrawText(e.Graphics, e.Header.Text, Theme.Bold,
                new Rectangle(r.X + 6, r.Y, Math.Max(1, r.Width - 8), r.Height), Theme.Text, CellFlags);
        }

        void lv_DrawItem(object s, DrawListViewItemEventArgs e)
        {
            e.DrawDefault = false;   // everything is painted per cell in DrawSubItem
        }

        void lv_DrawSub(object s, DrawListViewSubItemEventArgs e)
        {
            CopyItem it = cur == null ? null : cur.GetItem(e.ItemIndex);
            Graphics g = e.Graphics;
            Rectangle r = e.Bounds;
            if (e.ColumnIndex == 0) r.Width = lv.Columns[0].Width;   // first-column bounds quirk
            bool sel = (e.ItemState & ListViewItemStates.Selected) != 0;
            g.FillRectangle(sel ? Theme.BrSel : ((e.ItemIndex & 1) == 0 ? Theme.BrRow1 : Theme.BrRow2), r);
            if (it == null) return;

            Rectangle tr = new Rectangle(r.X + 6, r.Y, Math.Max(1, r.Width - 10), r.Height);
            bool paused = cur.Paused;
            switch (e.ColumnIndex)
            {
                case 0:
                    TextRenderer.DrawText(g, it.Name == null ? "" : it.Name, Theme.Cell, tr, Theme.Text,
                        TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.PathEllipsis |
                        TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine);
                    break;
                case 1:
                    TextRenderer.DrawText(g, it.Src == null ? "" : Fmt.Size(it.Size), Theme.Cell, tr, Theme.Dim,
                        TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine);
                    break;
                case 2:
                    {
                        int st = it.State;
                        Color a, b;
                        Theme.BarColors(st, paused, out a, out b);
                        double f = it.Fraction;
                        string txt = (st == 0 || it.Src == null) ? "" : ((int)(f * 100)) + "%";
                        Gfx.Bar(g, new Rectangle(r.X + 4, r.Y + 4, r.Width - 8, r.Height - 8), f, a, b, txt, false, 0, 3);
                    }
                    break;
                case 3:
                    if (it.State == 1)
                        TextRenderer.DrawText(g, paused ? "paused" : Fmt.Size((long)it.Speed) + "/s", Theme.Cell, tr, Theme.Text,
                            TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine);
                    break;
                case 4:
                    if (it.State == 1 && !paused && it.Speed > 1)
                    {
                        double left = (it.Size - Interlocked.Read(ref it.Done)) / it.Speed;
                        TextRenderer.DrawText(g, Fmt.Time(left), Theme.Cell, tr, Theme.Text,
                            TextFormatFlags.Right | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine);
                    }
                    break;
                case 5:
                    {
                        string t; Color c;
                        switch (it.State)
                        {
                            case 1: t = paused ? "Paused" : "Copying"; c = paused ? Theme.Orange : Theme.Cyan; break;
                            case 2: t = "Done"; c = Theme.Green; break;
                            case 3: t = "Error: " + it.Error; c = Theme.Red; break;
                            case 4: t = "Skipped"; c = Theme.Dim; break;
                            case 5: t = "Cancelled"; c = Theme.Orange; break;
                            default: t = "Pending"; c = Theme.Dim; break;
                        }
                        TextRenderer.DrawText(g, t, Theme.Cell, tr, c, CellFlags);
                    }
                    break;
            }
        }

        // ------------------------------------------------------------
        //  owner-drawn job strip
        // ------------------------------------------------------------
        void jobBox_DrawItem(object s, DrawItemEventArgs e)
        {
            if (e.Index < 0 || e.Index >= jobs.Count) return;
            CopyJob j = jobs[e.Index];
            Graphics g = e.Graphics;
            bool sel = (e.State & DrawItemState.Selected) != 0;
            g.FillRectangle(sel ? Theme.BrSel : Theme.BrPanel, e.Bounds);

            Rectangle tr = new Rectangle(e.Bounds.X + 8, e.Bounds.Y, Math.Max(10, e.Bounds.Width - 240), e.Bounds.Height);
            TextRenderer.DrawText(g, (e.Index + 1) + ".  " + (j.Move ? "Move " : "Copy ") + j.Summary,
                Theme.Cell, tr, Theme.Text, CellFlags);

            int st = !j.Started ? 0 : (j.Finished ? (j.Cancelled ? 5 : (j.Errors > 0 ? 3 : 2)) : 1);
            Color a, b;
            Theme.BarColors(st, j.Paused, out a, out b);
            double f = (j.Finished && !j.Cancelled) ? 1.0 : j.Fraction;
            string txt = !j.Started ? "Queued" : ((int)Math.Round(f * 100)) + "%";
            Gfx.Bar(g, new Rectangle(e.Bounds.Right - 218, e.Bounds.Y + 5, 206, e.Bounds.Height - 10), f, a, b, txt, false, 0, 4);
        }
    }

    // ================================================================
    //  Settings window
    // ================================================================
    class SettingsForm : Form
    {
        NumericUpDown numConc;
        ComboBox cmbBuf, cmbConf;
        CheckBox chkClose;
        Label lblState;
        static readonly int[] BufSizes = new int[] { 64, 256, 1024, 4096 };

        Label MakeLabel(string text, int x, int y, Color c)
        {
            Label l = new Label();
            l.Text = text;
            l.AutoSize = true;
            l.ForeColor = c;
            l.BackColor = Theme.Bg;
            l.Location = new Point(x, y);
            return l;
        }

        public SettingsForm()
        {
            Text = "Super Copy - Settings";
            Font = Theme.Cell;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(430, 396);
            BackColor = Theme.Bg;
            Icon = IconMaker.MakeIcon();

            TitleBar tb = new TitleBar();
            tb.Title = "Super Copy";
            tb.Sub = "Fast, light file copier with Explorer integration";
            tb.Dock = DockStyle.Top;
            tb.Height = 56;
            Controls.Add(tb);

            Controls.Add(MakeLabel("Concurrent copies (1 - 8):", 20, 76, Theme.Text));
            numConc = new NumericUpDown();
            numConc.Minimum = 1; numConc.Maximum = 8;
            numConc.Value = Math.Max(1, Math.Min(8, Settings.Concurrency));
            numConc.SetBounds(300, 72, 100, 22);
            numConc.BackColor = Theme.Panel2; numConc.ForeColor = Color.White;
            Controls.Add(numConc);
            Controls.Add(MakeLabel("1-2 is best for one hard disk; 4+ helps with many small files or SSDs.", 20, 98, Theme.Dim));

            Controls.Add(MakeLabel("Copy buffer per thread:", 20, 132, Theme.Text));
            cmbBuf = new ComboBox();
            cmbBuf.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbBuf.Items.AddRange(new object[] { "64 KB", "256 KB", "1 MB", "4 MB" });
            int bi = 1;
            for (int i = 0; i < BufSizes.Length; i++) if (BufSizes[i] == Settings.BufferKB) bi = i;
            cmbBuf.SelectedIndex = bi;
            cmbBuf.SetBounds(240, 128, 160, 22);
            Controls.Add(cmbBuf);

            Controls.Add(MakeLabel("If a file already exists:", 20, 168, Theme.Text));
            cmbConf = new ComboBox();
            cmbConf.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbConf.Items.AddRange(new object[] { "Overwrite", "Skip", "Keep both (rename)", "Overwrite only if newer" });
            cmbConf.SelectedIndex = Math.Max(0, Math.Min(3, Settings.Conflict));
            cmbConf.SetBounds(240, 164, 160, 22);
            Controls.Add(cmbConf);

            chkClose = new CheckBox();
            chkClose.Text = "Close the window automatically when finished";
            chkClose.AutoSize = true;
            chkClose.ForeColor = Theme.Text;
            chkClose.BackColor = Theme.Bg;
            chkClose.Checked = Settings.AutoClose;
            chkClose.Location = new Point(20, 204);
            Controls.Add(chkClose);

            Controls.Add(MakeLabel("Explorer right-click menu", 20, 244, Theme.Cyan));
            Button bi2 = UI.MakeButton("Install menu", 180, Color.FromArgb(40, 150, 100));
            Button br = UI.MakeButton("Remove menu", 180, Color.FromArgb(190, 60, 80));
            bi2.Location = new Point(20, 266);
            br.Location = new Point(220, 266);
            bi2.Click += new EventHandler(OnInstall);
            br.Click += new EventHandler(OnRemove);
            Controls.Add(bi2);
            Controls.Add(br);
            lblState = MakeLabel("", 20, 304, Theme.Dim);
            Controls.Add(lblState);
            Controls.Add(MakeLabel("Windows 11: entries are under \"Show more options\" (Shift+F10).", 20, 324, Theme.Dim));
            RefreshState();

            Button ok = UI.MakeButton("Save", 90, Color.FromArgb(70, 90, 170));
            Button cancel = UI.MakeButton("Cancel", 90, Color.FromArgb(70, 76, 110));
            ok.Location = new Point(236, 356);
            cancel.Location = new Point(334, 356);
            ok.Click += new EventHandler(OnSave);
            cancel.Click += new EventHandler(OnCancel);
            Controls.Add(ok);
            Controls.Add(cancel);
            AcceptButton = ok;
            CancelButton = cancel;
        }

        void RefreshState()
        {
            bool on = ShellIntegration.IsInstalled();
            lblState.Text = on ? "Status: installed (Super Copy / Super Cut / Super Paste here)" : "Status: not installed";
            lblState.ForeColor = on ? Theme.Green : Theme.Dim;
        }

        void OnInstall(object s, EventArgs e)
        {
            try
            {
                ShellIntegration.Install();
                RefreshState();
                MessageBox.Show(this, "Done.\n\n1. Right-click files/folders > Super Copy (or Super Cut)\n2. Right-click a folder (or empty space inside it) > Super Paste here",
                    "Super Copy", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Super Copy", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        void OnRemove(object s, EventArgs e)
        {
            try { ShellIntegration.Uninstall(); RefreshState(); }
            catch (Exception ex) { MessageBox.Show(this, ex.Message, "Super Copy", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        void OnSave(object s, EventArgs e)
        {
            Settings.Concurrency = (int)numConc.Value;
            Settings.BufferKB = BufSizes[Math.Max(0, cmbBuf.SelectedIndex)];
            Settings.Conflict = Math.Max(0, cmbConf.SelectedIndex);
            Settings.AutoClose = chkClose.Checked;
            Settings.Save();
            DialogResult = DialogResult.OK;
            Close();
        }

        void OnCancel(object s, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
